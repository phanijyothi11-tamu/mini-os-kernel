/*
	File: kernel.C

	Author: R. Bettati
			Department of Computer Science
			Texas A&M University
	Date  : 2024/11/02


	This file has the main entry point to the operating system.

	MAIN FILE FOR MACHINE PROBLEM "KERNEL-LEVEL DEVICE MANAGEMENT"

*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- COMMENT/UNCOMMENT THE FOLLOWING LINE TO EXCLUDE/INCLUDE SCHEDULER CODE */

//#define _USES_SCHEDULER_
/* This macro is defined when we want to force the code below to use
   a scheduler.
   Otherwise, no scheduler is used, and the threads pass control to each
   other in a co-routine fashion.
*/

#define MB * (0x1 << 20)
#define KB * (0x1 << 10)

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "machine.H"         /* LOW-LEVEL STUFF   */
#include "console.H"
#include "gdt.H"
#include "idt.H"             /* EXCEPTION MGMT.   */
#include "irq.H"
#include "exceptions.H"     
#include "interrupts.H"

#include "simple_timer.H"    /* TIMER MANAGEMENT  */

#include "frame_pool.H"      /* MEMORY MANAGEMENT */
#include "mem_pool.H"

#include "thread.H"         /* THREAD MANAGEMENT */

#include "scheduler.H"      /* WE WILL NEED A SCHEDULER WITH NonBlockingDisk */

#include "simple_disk.H"    /* DISK DEVICE */
							/* YOU MAY NEED TO INCLUDE nonblocking_disk.H */

#include "system.H"         /* SYSTEM COMPONENTS: SCHEDULER, MEMORY, DISK */

Scheduler* SYSTEM_SCHEDULER = nullptr;

/*--------------------------------------------------------------------------*/
/* MEMORY MANAGEMENT */
/*--------------------------------------------------------------------------*/

typedef unsigned int size_t;

//replace the operator "new"
void* operator new (size_t size)
{
	unsigned long a = System::MEMORY_POOL->allocate((unsigned long)size);
	return (void*)a;
}

//replace the operator "new[]"
void* operator new[](size_t size)
{
	unsigned long a = System::MEMORY_POOL->allocate((unsigned long)size);
	return (void*)a;
}

//replace the operator "delete"
void operator delete (void* p, size_t size)
{
	System::MEMORY_POOL->release((unsigned long)p);
}

//replace the operator "delete[]"
void operator delete[](void* p)
{
	System::MEMORY_POOL->release((unsigned long)p);
}

/*--------------------------------------------------------------------------*/
/* DISK */
/*--------------------------------------------------------------------------*/

// The disk is defined in class System as System::DISK

#define DISK_BLOCK_SIZE ((1 KB) / 2)

/*--------------------------------------------------------------------------*/
/* JUST AN AUXILIARY FUNCTION */
/*--------------------------------------------------------------------------*/

void pass_on_CPU(Thread* _to_thread)
{
#ifndef _USES_SCHEDULER_
	/* We don't use a scheduler. Explicitely pass control to the next
	   thread in a co-routine fashion. */
	Thread::dispatch_to(_to_thread);
#else
	/* We use a scheduler. Instead of dispatching to the next thread,
	   we pre-empt the current thread by putting it onto the ready
	   queue and yielding the CPU. */

	System::SCHEDULER->resume(Thread::CurrentThread());
	System::SCHEDULER->yield();
#endif
}

/*--------------------------------------------------------------------------*/
/* A FEW THREADS (pointer to TCB's and thread functions) */
/*--------------------------------------------------------------------------*/

Thread* thread1; // simply prints out to console
Thread* thread2; // performs READ/WRITE operations on disk
Thread* thread3; // simply prints out to console
Thread* thread4; // simply prints out to console

void fun1()
{
	Console::puts("THREAD: "); Console::puti(Thread::CurrentThread()->ThreadId()); Console::puts("\n");

	Console::puts("FUN 1 INVOKED!\n");

	for (int j = 0;; j++) {

		Console::puts("FUN 1 IN ITERATION["); Console::puti(j); Console::puts("]\n");

		for (int i = 0; i < 10; i++) {
			Console::puts("FUN 1: TICK ["); Console::puti(i); Console::puts("]\n");
		}

		pass_on_CPU(thread2);
	}
}
static unsigned char buf[DISK_BLOCK_SIZE];  // safe across thread yields
void fun2()
{
	Console::puts("THREAD: "); Console::puti(Thread::CurrentThread()->ThreadId()); Console::puts("\n");

	Console::puts("FUN 2 INVOKED!\n");

	// unsigned char buf[DISK_BLOCK_SIZE];
	int  read_block = 1;
	int  write_block = 0;

	for (int j = 0;; j++) {

		Console::puts("FUN 2 IN ITERATION["); Console::puti(j); Console::puts("]\n");

		/* -- Read */
		Console::puts("Reading Block "); Console::puti(read_block); Console::puts(" from disk...\n");
		System::DISK->read(read_block, buf);
		Console::puts("\nContent of block is:");
		for (int i = 0; i < DISK_BLOCK_SIZE; i++) {
			Console::putui((unsigned int)buf[i]);
			buf[i] = j % 256;
		}
		Console::puts("\n");

		Console::puts("Writing buffer to Block "); Console::puti(write_block); Console::puts(" on disk...\n");
		System::DISK->write(write_block, buf);
		Console::puts("\nDone writing\n");

		/* -- Move to next block */
		write_block = read_block;
		read_block = (read_block + 1) % 10;

		/* -- Give up the CPU */
		pass_on_CPU(thread3);
	}
}

void fun3()
{
	Console::puts("THREAD: "); Console::puti(Thread::CurrentThread()->ThreadId()); Console::puts("\n");

	Console::puts("FUN 3 INVOKED!\n");

	for (int j = 0;; j++) {

		Console::puts("FUN 3 IN BURST["); Console::puti(j); Console::puts("]\n");

		for (int i = 0; i < 10; i++) {
			Console::puts("FUN 3: TICK ["); Console::puti(i); Console::puts("]\n");
		}

		pass_on_CPU(thread4);
	}
}

void fun4()
{
	Console::puts("THREAD: "); Console::puti(Thread::CurrentThread()->ThreadId()); Console::puts("\n");

	for (int j = 0;; j++) {

		Console::puts("FUN 4 IN BURST["); Console::puti(j); Console::puts("]\n");

		for (int i = 0; i < 10; i++) {
			Console::puts("FUN 4: TICK ["); Console::puti(i); Console::puts("]\n");
		}

		pass_on_CPU(thread1);
	}
}

/*--------------------------------------------------------------------------*/
/* MAIN ENTRY INTO THE OS */
/*--------------------------------------------------------------------------*/

int main()
{

	GDT::init();
	Console::init();
	IDT::init();
	ExceptionHandler::init_dispatcher();
	IRQ::init();
	InterruptHandler::init_dispatcher();

	/* -- SEND OUTPUT TO TERMINAL -- */
	Console::redirect_output(true);

	/* -- EXAMPLE OF AN EXCEPTION HANDLER -- */

	class DBZ_Handler : public ExceptionHandler {
	public:
		virtual void handle_exception(REGS* _regs)
		{
			Console::puts("DIVISION BY ZERO!\n");
			for (;;);
		}
	} dbz_handler;

	ExceptionHandler::register_handler(0, &dbz_handler);

	/* -- INITIALIZE MEMORY -- */
	/*    NOTE: We don't have paging enabled in this MP. */
	/*    NOTE2: This is not an exercise in memory management. The implementation
				of the memory management is accordingly *very* primitive! */

				/* ---- Initialize a frame pool; details are in its implementation */
	FramePool system_frame_pool;
	FramePool* SYSTEM_FRAME_POOL = &system_frame_pool;

	/* ---- Create a memory pool of 256 frames. */
	MemPool memory_pool(SYSTEM_FRAME_POOL, 256); // We don't have a memory manager yet. Pool is on the stack.
	System::MEMORY_POOL = &memory_pool;

	/* -- MEMORY ALLOCATOR SET UP. WE CAN NOW USE NEW/DELETE! -- */

	/* -- INITIALIZE THE TIMER (we use a very simple timer).-- */

	/* Question: Why do we want a timer? We have it to make sure that
				 we enable interrupts correctly. If we forget to do it,
				 the timer "dies". */

	SimpleTimer timer(100); /* timer ticks every 10ms. */
	InterruptHandler::register_handler(0, &timer);
	/* The Timer is implemented as an interrupt handler. */

	/* -- DISK DEVICE -- */

	// System::DISK = new SimpleDisk(System::DISK_SIZE); // Replace this with commented code below when you are ready!

	#define _USES_SCHEDULER_
	// The NonBlockingDisk uses a scheduler.
	System::DISK = new NonBlockingDisk(System::DISK_SIZE);

	/* -- SCHEDULER -- IF YOU HAVE ONE -- */

#ifdef _USES_SCHEDULER_
	System::SCHEDULER = new Scheduler();
	SYSTEM_SCHEDULER = System::SCHEDULER;
#endif

	/* -- ENABLE INTERRUPTS -- */

	Machine::enable_interrupts();

	/* -- MOST OF WHAT WE NEED IS SETUP. THE KERNEL CAN START. */

	Console::puts("Hello World!\n");

	/* -- LET'S CREATE SOME THREADS... */

	Console::puts("CREATING THREAD 1...\n");
	char* stack1 = new char[1024];
	thread1 = new Thread(fun1, stack1, 1024);
	Console::puts("DONE\n");

	Console::puts("CREATING THREAD 2...");
	char* stack2 = new char[1024];
	thread2 = new Thread(fun2, stack2, 1024);
	Console::puts("DONE\n");

	Console::puts("CREATING THREAD 3...");
	char* stack3 = new char[1024];
	thread3 = new Thread(fun3, stack3, 1024);
	Console::puts("DONE\n");

	Console::puts("CREATING THREAD 4...");
	char* stack4 = new char[1024];
	thread4 = new Thread(fun4, stack4, 1024);
	Console::puts("DONE\n");

#ifdef _USES_SCHEDULER_
	/* WE ADD thread2 - thread4 TO THE READY QUEUE OF THE SCHEDULER. */

	System::SCHEDULER->add(thread2);
	System::SCHEDULER->add(thread3);
	System::SCHEDULER->add(thread4);
#endif

	/* -- KICK-OFF THREAD1 ... */

	Console::puts("STARTING THREAD 1 ...\n");
	Thread::dispatch_to(thread1);

	/* -- AND ALL THE REST SHOULD FOLLOW ... */

	assert(false); /* WE SHOULD NEVER REACH THIS POINT. */

	/* -- WE DO THE FOLLOWING TO KEEP THE COMPILER HAPPY. */
	return 1;
}
